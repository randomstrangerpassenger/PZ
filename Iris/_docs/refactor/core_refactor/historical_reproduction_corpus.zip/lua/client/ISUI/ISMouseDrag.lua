
ISMouseDrag = {}

ISMouseDrag.dragView = nil;
