"""Public use frames over structured A relations and admitted participant roles.

Execution evidence stays in the input. Only claims actually expressed are linked
as public facts; no procedure refs are attached to a shorter unrelated sentence.
"""
from copy import deepcopy
from . import description_composition_lexicon as lex
from . import description_composition_en as en
from . import description_composition_ko as ko

MAINTENANCE = {'wash_carried_equipment', 'receive_garment_patch', 'remove_garment_patch',
               'rename_selected_item', 'rename_prepared_food'}
WASH_RESULTS = {'item_surface_blood', 'clothing_surface_dirt', 'clothing_wetness',
                'washed_surface_blood', 'washed_surface_dirt', 'food_chef_attribution'}
FUEL = {'supply_campfire_fuel': ('모닥불', 'campfires'),
        'supply_hearth_fuel': ('비프로판 바비큐·벽난로', 'non-propane barbecues and fireplaces'),
        'supply_furnace_fuel': ('화로', 'furnaces')}
TINDER = {'provide_campfire_tinder': ('모닥불', 'campfires'),
          'provide_hearth_tinder': ('비프로판 바비큐·벽난로', 'non-propane barbecues and fireplaces'),
          'provide_industrial_tinder': ('통나무가 든 드럼', 'drums containing logs')}


def internal_reason(unit):
    if any(f['payload'].get('function') in MAINTENANCE for f in unit['facts']):
        return 'care of the item, not a use supplied by it'
    if any(f['payload'].get('property') in WASH_RESULTS for f in unit['facts']):
        return 'procedure outcome or attribution metadata, not an independent item use'
    if any(f['fact_kind'] == 'acquisition' for f in unit['facts']):
        return 'acquisition belongs to L3 acquisition supply, not DVF use prose'
    return None


def frames(plan, locale, links, compact):
    output, used = [], set()
    units = plan['units']

    def select(functions):
        return [u for u in units if any(f['payload'].get('function') in functions for f in u['facts'])
                and not set(u['fact_refs']) & used]

    def emit(members, text):
        if not members:
            return
        # These frames express the admitted capability and selected structured
        # relationships, not the complete execution predicate.
        claims = [dict(u, qualifier_refs=[]) for u in members]
        output.append({'text': text + '.', **links(claims, plan), 'expression': 'public_use',
                       'placement_reason': 'role and confirmed result use; execution evidence retained internally',
                       'qualifier_dispositions': []})
        used.update(r for u in members for r in u['fact_refs'])

    def names(items):
        words = list(dict.fromkeys(i['names'][locale] for i in items))
        return '·'.join(words) if locale == 'ko' else en.join(words)

    def object_name(noun):
        final = (ord(noun[-1]) - ord('가')) % 28 if '가' <= noun[-1] <= '힣' else 0
        return noun + ('을' if final else '를')

    for relation in plan.get('use_relations', []):
        if relation['function'] in {'unpack_box_contents', 'unpack_eggs', 'unpack_jarred_food'}:
            continue  # Existing callback-specific packaging frames own these uses.
        refs = set(relation['fact_refs'])
        members = [u for u in units if refs & set(u['fact_refs']) and not used & set(u['fact_refs'])]
        if not members:
            continue
        fn = relation['function']
        activity = 'frog_preparation' if fn == 'prepare_frog_meat' else 'electronic_salvage' if fn == 'dismantle_electronics' else 'package_opening'
        members += [u for u in units if any(f['payload'].get('activity') == activity for f in u['facts'])
                    and any(f['payload'].get('role') in {'material', 'transformation_target'} for f in u['facts'])
                    and not used & set(u['fact_refs'])]
        results = relation['results']
        certain = [r for r in results if r['kind'] != 'callback_conditional']
        possible = [r for r in results if r['kind'] == 'callback_conditional']
        result_name = names(certain)
        tool_groups = [(' 또는 ' if locale == 'ko' else ' or ').join(dict.fromkeys(i['names'][locale] for i in group['items'])) for group in relation['tools']]
        tool_text = (' 및 '.join(tool_groups) if locale == 'ko' else ' and '.join(tool_groups))
        if fn == 'prepare_frog_meat' and compact:
            tool_text = '칼' if locale == 'ko' else 'a knife'
        if locale == 'ko':
            method = ('도구 없이 ' if not tool_text else ko.instrumental(tool_text) + ' ')
            action = '손질해' if fn == 'prepare_frog_meat' else '분해해' if fn == 'dismantle_electronics' else '개봉해'
            text = method + action + ' ' + object_name(result_name) + ' 얻을 수 있다'
            if relation['result_use'] == 'prepare_opened_food_ingredient':
                text = method + action + ' 꺼낸 ' + object_name(result_name) + ' 요리 재료로 쓸 수 있다'
            elif relation['result_use'] == 'sow_extracted_seeds':
                text = '봉지를 열어 꺼낸 ' + object_name(result_name) + ' 파종하는 데 쓸 수 있다'
            if possible:
                text += '. ' + names(possible) + '도 나올 수 있다'
            if not compact and tool_groups:
                text += '. 도구는 소모하지 않는다'
        else:
            action = 'prepared' if fn == 'prepare_frog_meat' else 'dismantled' if fn == 'dismantle_electronics' else 'opened'
            method = ' with ' + tool_text if tool_text else ' without tools'
            text = 'It can be ' + action + method + ' to obtain ' + result_name
            if relation['result_use'] == 'prepare_opened_food_ingredient':
                text += ' for use as a cooking ingredient'
            elif relation['result_use'] == 'sow_extracted_seeds':
                text += ' for sowing'
            if possible:
                text += '. ' + names(possible) + ' may also be recovered'
            if not compact and tool_groups:
                text += '. The tools are not consumed'
        if not compact and relation['result_use'] == 'sow_extracted_seeds':
            text += ('. 봉지의 선언된 내용물 수량은 ' + certain[0]['count'] + '개다' if locale == 'ko'
                     else '. The packet declares ' + certain[0]['count'] + ' seeds')
        emit(members, text)

    washing = select({'wash_body', 'wash_equipment'})
    if washing:
        functions = {f['payload'].get('function') for u in washing for f in u['facts']}
        targets = []
        if 'wash_body' in functions: targets.append(('몸', 'the body'))
        if 'wash_equipment' in functions: targets.append(('의류·장비', 'clothing and equipment'))
        emit(washing, ('몸과 의류·장비를 물로 씻을 때 쓰는 세척제다' if len(targets) == 2 else targets[0][0] + '를 물로 씻을 때 쓰는 세척제다')
             if locale == 'ko' else 'It is a cleaning supply for washing ' + en.join([t[1] for t in targets]) + ' with water')
    if compact and select(FUEL) and select(TINDER):
        emit(select(FUEL) + select(TINDER), '연료·불쏘시개로 소모할 수 있다' if locale == 'ko' else 'It can be consumed as fuel or as tinder')
    for functions, role in ((FUEL, ('연료', 'fuel')), (TINDER, ('불쏘시개', 'tinder'))):
        members = select(functions)
        if not members: continue
        targets = [lex.pair(functions[f['payload']['function']], locale) for u in members for f in u['facts']]
        text = role[0] + '로 소모할 수 있다' if locale == 'ko' else 'It can be consumed as ' + role[1]
        if not compact:
            text = '·'.join(dict.fromkeys(targets)) + '의 ' + role[0] + '로 소모할 수 있다' if locale == 'ko' else text + ' for ' + en.join(list(dict.fromkeys(targets)))
        emit(members, text)
    wearing = select({'wear_on_body', 'wear_configured_clothing'})
    locations = [u for u in units if any(f['payload'].get('state') == 'worn_location' for f in u['facts'])]
    if wearing:
        location = lex.core(locations[0]['facts'][0], locale, True) if locations else None
        if locale == 'ko' and location and location.startswith('착용 위치는 ') and location.endswith('다'):
            location = location.removeprefix('착용 위치는 ').removesuffix('다').removesuffix('이') + '에 착용한다'
        emit(wearing + locations, (location if location else ('몸에 착용할 수 있다' if locale == 'ko' else 'It can be worn')))
    fabric = [u for u in units if any(f['payload'].get('activity') == 'fabric_recovery' for f in u['facts'])]
    if fabric and plan.get('source_traits', {}).get('FabricType') in {'Cotton', 'Denim', 'Leather'}:
        needs_scissors = plan['source_traits']['FabricType'] in {'Denim', 'Leather'}
        text = ('가위로 찢어 직물을 회수하는 재료다' if needs_scissors else '찢어 직물을 회수하는 재료다') if locale == 'ko' else (
            'It is material for recovering fabric by ripping' + (' with scissors' if needs_scissors else ''))
        if not compact:
            text += '. 회수 재료와 양은 옷의 구성·오염·재봉 상태에 따라 달라진다' if locale == 'ko' else '. Recovered material and amounts depend on garment construction, contamination and tailoring state'
        emit(fabric, text)
    # Named ignition branches retain method/target compatibility without the
    # movement, inventory, repeated validity and per-action use-count prose.
    from .description_composition_families import IGNITION, IGNITION_TARGETS
    ignition = select(set(IGNITION) | {'request_corpse_burning'})
    candle_tools = [u for u in units if any(f['payload'].get('activity') == 'candle_lighting' for f in u['facts'])
                    and any(f['payload'].get('role') == 'tool' for f in u['facts'])]
    if compact and ignition:
        emit(ignition + candle_tools, ('불을 붙이는 도구로 쓴다' if candle_tools else '불을 붙이는 데 쓸 수 있다') if locale == 'ko'
             else ('It is a tool for lighting fires' if candle_tools else 'It can be used for lighting fires'))
    elif ignition:
        grouped = {}
        for u in ignition:
            fn = u['facts'][0]['payload']['function']
            if fn == 'request_corpse_burning':
                emit([u], '휘발유와 점화 도구로 시신에 불을 붙이는 데 쓴다' if locale == 'ko' else 'It is used with petrol and an igniter to set fire to corpses')
                continue
            _, targets, methods = IGNITION[fn]
            grouped.setdefault(methods, ([], []))[0].append(u)
            grouped[methods][1].extend(targets)
        for methods, (members, targets) in grouped.items():
            targets = list(dict.fromkeys(targets))
            target_names = [lex.pair(IGNITION_TARGETS[t], locale) for t in targets]
            # Preserve the legacy heat-source capability as a bounded action,
            # not a guarantee of native fire activation.
            bounded = any(t in {'furnace', 'fireplace', 'barbecue'} for t in targets)
            if locale == 'ko':
                method = ' 또는 '.join('휘발유' if m == 'petrol' else '불쏘시개' for m in methods)
                text = '·'.join(target_names) + '에 ' + method + '와 점화 도구를 사용하는 점화 동작에 쓸 수 있다'
            else:
                text = 'It can participate in lighting ' + en.join(target_names) + ' using ' + ' or '.join(methods) + ' and an igniter'
            if bounded:
                text += '. 실제 점화는 해당 대상의 지원 상태에 달려 있다' if locale == 'ko' else '. Actual ignition depends on support for the target'
            emit(members, text)
        if candle_tools:
            emit(candle_tools, '초에 불을 붙이는 도구로 쓴다' if locale == 'ko' else 'It is a tool for lighting candles')
    light = select({'control_portable_light'})
    if light:
        emit(light, '현재 상태가 허용하면 휴대 조명으로 쓸 수 있다' if locale == 'ko' else 'It can serve as a portable light when its current state permits emission')
    return output, used


def prepare(plan):
    public = deepcopy(plan)
    public['units'] = [u for u in public['units'] if not internal_reason(u)]
    if any(f['payload'].get('function') == 'control_portable_light' for u in public['units'] for f in u['facts']):
        public['units'] = [u for u in public['units'] if not any(f['payload'].get('function') in {'toggle_activation'} for f in u['facts'])]
    return public
