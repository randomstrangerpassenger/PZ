"""Expose named participants from admitted source observations, without changing r6.

This is an A source adapter. A recipe is considered only through an admitted
function's provenance; result uses require their own admitted function. Prose
consumers receive structured values and never interpret recipe text.
"""
from collections import defaultdict
import hashlib
import re

from . import source_reader as reader

FUNCTIONS = {'unpack_canned_food', 'unpack_produce', 'unpack_ammunition',
             'unpack_seeds', 'unpack_eggs', 'unpack_jarred_food',
             'unpack_box_contents', 'prepare_frog_meat', 'dismantle_electronics'}
# Food concepts, not FullType sentence overrides. Preserve exact result identity.
FOOD_NAMES = {'Corn': '옥수수', 'Corned Beef': '콘비프', 'Sardine': '정어리',
              'Carrots': '당근', 'Carrot': '당근', 'Beans': '콩',
              'Bolognese': '볼로네제', 'Peas': '완두콩', 'Potato': '감자',
              'Tomato': '토마토', 'Peach': '복숭아', 'Pineapple': '파인애플',
              'Bean': '콩', 'Pea': '완두콩', 'Chili': '칠리', 'Fruit': '과일',
              'Evaporated Milk': '무가당 농축 우유', 'Mushroom': '버섯',
              'Vegetable': '채소', 'Tuna': '참치', 'Dog Food': '개 사료'}


def enrich(root, semantic, composition):
    observations = semantic['observations']
    declarations = {}
    declaration_refs = {}
    for ref, observation in observations.items():
        content = observation.get('content', {})
        if not isinstance(content, dict) or not content.get('raw', '').lstrip().startswith('item '):
            continue
        item = observation['locator'].rsplit(':', 1)[-1]
        if not re.fullmatch(r'\w+\.\w+', item) or content.get('property_conflicts'):
            continue
        props = reader.properties({'clauses': content.get('clauses', [])}, '=')
        declarations[item] = {k: v[0] for k, v in props.items() if len(v) == 1}
        declaration_refs[item] = ref
    locale_path = 'lua/shared/Translate/KO/ItemName_KO.txt'
    locale_raw = (root / locale_path).read_bytes()
    locale_text = locale_raw.decode('utf-16' if locale_raw[:2] in (b'\xff\xfe', b'\xfe\xff') else 'utf-8-sig')
    labels = dict(re.findall(r'ItemName_([\w.]+)\s*=\s*"([^"]+)"', locale_text))

    def named(item, food=False):
        fields = declarations[item]
        concept = fields.get('EvolvedRecipeName') if food and fields.get('EvolvedRecipe') else None
        english = concept or fields.get('DisplayName')
        korean = FOOD_NAMES.get(concept) if concept else None
        return {'item_id': item, 'names': {'en': english or item,
                'ko': korean or labels.get(item, english or item)},
                'name_basis': 'EvolvedRecipeName' if korean else 'DisplayName/ItemName',
                'observation_ref': declaration_refs[item]}

    by_item = defaultdict(list)
    for fact in semantic['facts']:
        by_item[fact['item_id']].append(fact)
    groups_text = next((o['content']['source_text'] for o in observations.values()
                        if isinstance(o.get('content'), dict) and o.get('source_path') == 'lua/server/recipecode.lua'
                        and 'source_text' in o['content']), '')
    groups = reader.groups(groups_text)
    for item in composition['items']:
        item_id = item['item_id']
        item['source_traits'] = {k: declarations.get(item_id, {})[k]
                                 for k in ('FabricType',) if k in declarations.get(item_id, {})}
        relations = []
        functions = {f['payload'].get('function'): f for f in by_item[item_id]
                     if f['fact_kind'] == 'direct_function'}
        for fn in sorted(FUNCTIONS & functions.keys()):
            fact = functions[fn]
            evidence = sorted({r for p in fact['provenance_refs']
                               for r in semantic['provenance'][p]['observation_refs']})
            for ref in evidence:
                observation = observations[ref]
                content = observation.get('content', {})
                if not isinstance(content, dict) or not content.get('raw', '').lstrip().startswith('recipe '):
                    continue
                record = {'clauses': content['clauses'], 'module': item_id.split('.')[0]}
                participants, opaque = reader.recipe_participants(record, declarations, groups)
                if opaque or not any(p['item_id'] == item_id and p['role'] in {'input', 'destroy'} for p in participants):
                    continue
                outputs = [p for p in participants if p['role'] == 'result']
                if len(outputs) != 1 or outputs[0]['item_id'] not in declarations:
                    continue
                output = outputs[0]
                tools = defaultdict(list)
                for p in participants:
                    if p['role'] == 'keep' and p['item_id'] in declarations:
                        tool = named(p['item_id'])
                        if 'CanOpener' in declarations[p['item_id']].get('Tags', '').split(';'):
                            tool['names']['ko'] = '통조림 따개'
                        tools[p['ordinal']].append(tool)
                result = named(output['item_id'], food=fn in {'unpack_canned_food', 'unpack_produce', 'unpack_jarred_food'})
                result.update(kind='declared', count=output['clause'].split('=', 1)[1] if '=' in output['clause'] else '1')
                relation = {'function': fn, 'fact_refs': [fact['fact_id']], 'input_role': 'transformation_target',
                            'tools': [{'mode': 'any_of', 'consumed': False, 'items': tools[n]} for n in sorted(tools)],
                            'results': [result], 'observation_refs': evidence, 'result_use': None}
                use = 'sow_extracted_seeds' if fn == 'unpack_seeds' else 'prepare_opened_food_ingredient'
                if use in functions and fn.startswith('unpack_'):
                    relation['result_use'] = use
                    relation['fact_refs'].append(functions[use]['fact_id'])
                props = reader.properties(record, ':')
                if props.get('OnCreate') == ['Recipe.OnCreate.DismantleTVRemote']:
                    # This reviewed callback adds scrap outside the random branch.
                    # Battery construction/delivery remains conditional.
                    callback = groups_text.split('function Recipe.OnCreate.DismantleTVRemote(', 1)[-1].split('\nfunction ', 1)[0]
                    if 'player:getInventory():AddItem("Base.ElectronicsScrap");' in callback and 'if (ZombRand(0,100) < success)' in callback:
                        for target, kind in [('Base.ElectronicsScrap', 'callback_unconditional'), ('Base.Battery', 'callback_conditional')]:
                            if target in declarations:
                                relation['results'].append({**named(target), 'kind': kind, 'count': None})
                relations.append(relation)
        item['use_relations'] = relations
    composition['source']['relation_adapter'] = {'name': 'admitted source participants', 'locale_path': locale_path,
        'locale_sha256': hashlib.sha256(locale_raw).hexdigest(),
        'producer_sha256': hashlib.sha256((root / 'Iris/tooling/src/iris_tooling/domains/layer3/recovery_relations.py').read_bytes()).hexdigest()}
    return composition
