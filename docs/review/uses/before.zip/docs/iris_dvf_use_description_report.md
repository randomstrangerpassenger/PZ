# Iris DVF 용도 설명 조사 보고서

2026-09-11 · 현재 checkout의 읽기 전용 조사와 보고서 작성. 구현·corpus 재생성·테스트·채택·상태 문서 변경은 수행하지 않았다. 기존 dirty/deleted/untracked 작업은 보존했다. 아래 예시는 교정 원칙을 설명하는 제안이며 생성·인게임 검증 완료 문안이 아니다.

## 판단

> 구현 단계의 근거 정정(2026-09-11): 아래 `scripts/recipes.txt:207`의 Make Pot of Soup 예시는 `:194`에서 시작하는 주석 구간에 들어 있다. 활성 미개봉 직접 조리 근거로 사용할 수 없다. 활성 TinnedBeans의 Make Bowl of Beans와 구분한다. 조사 당시 기록은 아래에 남기며, 이 정정은 보고서 전체를 구현 완료 기록으로 바꾸지 않는다.

핵심 결함은 **사실의 보존을 공개 문장 전량 출력으로 해석하는 것**이다. 양말의 세척 대상 사실, 세척 결과와 점화 절차는 근거가 있어도 양말의 용도가 되지는 않는다. 반대로 양말의 연료·불쏘시개 역할은 실제 용도이므로 남겨야 한다. 수동태를 능동형으로 바꾸거나 모든 대상 사실을 삭제하는 방식으로 해결할 수 없다.

현재 A의 source rule과 기능 키는 세척 대상/세척제, 불쏘시개/점화 도구를 상당 부분 구분한다. 문제 1은 그 사실과 관계를 보존한다. 문제 2가 이를 공개용 의미로 선택하지 않고 expanded에 거의 전량 문장화하고, 문제 3의 기존 수락 기준도 그 결과를 보존 대상으로 취급한다. 통조림에는 별도의 상류 정보 전달 결함이 있다. 개봉 결과와 도구를 원본에서 확인하지만 공개 조합 입력에 구체적인 관계·이름으로 전달하지 않는다.

판단 기준은 [Philosophy.md](Philosophy.md)의 근거 기반 게임 내 위키, 중립성, 같은 사실의 다른 깊이, Alt 최대 4줄과 이번 사용자 지시다. DVF는 L3 용도 설명을 맡는다. 멀티 프로필을 `primary_use` 하나로 환원하지 않는다. 메뉴는 용도 중심 확장 설명이며, 툴팁에서 빠진 절차의 수납처가 아니다.

## 읽은 범위와 한계

- 직접 출력 대조: `Socks_Ankle`, `Socks_Long`, `Soap2`, `CleaningLiquid2`, `Lighter`, `CannedCorn`, `CannedCornOpen`, `CannedBolognese`, `CannedSardines`, `CannedCornedBeef`, `TinnedBeans`, `TinOpener`, `Hammer`, `Notebook`. 특히 앞의 양말·비누·라이터·옥수수 사례는 blocks의 사실 키까지 추적했다.
- 데이터: `Iris/build/description/composition/{blocks,descriptions}.json`, r6 `semantic.json`. 큰 JSON은 PowerShell `ConvertFrom-Json`으로 파싱하여 필요한 item/field만 읽었다. 전체 item을 읽는 파싱 자체를 전면 품질 감사로 계산하지 않는다.
- 코드: A의 `recovery_sources.py`와 관련 migration 경계, 문제 1의 composition 모델·규칙, 문제 2의 planner/families/results/lexicon/model, 기존 문제 2 검사 중 보존 조건. 바닐라 scripts와 관련 세척·점화 Lua도 대조했다.
- 기존 문서: A·1·2 walkthrough, 문제 1 contract, 문제 3 plan/closeout 및 `docs/review/prose/review.json`의 검수 범위, B의 실제 Tooltip 표시 코드, C closeout·projection의 필요한 부분.
- 미확인: 나머지 item의 개별 문장 품질, 모든 역할 조합, 모든 영어 출력, 모든 점화 서버 경로의 재조사, 실제 PZ 폰트·해상도·UI scale, 외부 버전. 기존 미확정 native 효과와 실행 한계도 이번에 해소한 것으로 보지 않는다. 모드는 정규화 어댑터를 거쳐 유사 DVF/QG 입력이 된다는 전제를 따른다.

## 사례 추적

이하 코드 경로의 `layer3/`는 `Iris/tooling/src/iris_tooling/domains/layer3/`를 뜻한다. JSON 좌표는 `items[item_id=…]`로 표기한다. 해시형 ID는 해당 파일에서 항목을 찾는 좌표이며 새 증명 artifact가 아니다.

### 양말: 세척 대상은 세척 도구가 아니다

1. **원본 사실.** `scripts/clothing/clothing_shoes.txt:3,18`의 두 양말은 `Type=Clothing`, `BodyLocation=Socks`, `FabricType=Cotton`이다. `lua/client/TimedActions/ISWashClothing.lua:71`은 물 10단위, `:74` 이후는 `self.soaps` 사용, `:94` 이후는 `self.item`의 피·때 제거와 `setWetness(100)`, `:143`은 이동 중단을 기록한다. 처리 대상 item과 소모 세척제는 서로 다른 인자다.
2. **A 역할.** `layer3/recovery_sources.py:2718` 이후는 Clothing/Weapon/Container에 `wash_carried_equipment`를 `washing_target` rule로 부여한다. 옷에는 혈흔·때 제거와 젖음 결과가 붙는다. `Soap2`/`CleaningLiquid2`는 별도의 `washing_supplies` rule 아래 `wash_body`, `wash_equipment`를 얻는다(`:2730` 이후). 대상이라는 뜻은 rule/function에 남아 있으나, `direct_function` kind만으로는 행위 주체를 구분할 수 없다.
3. **문제 1 블록.** 양말 `block:875466eca2beb336d81d257e4a5656a691ae0487a76fc23961ceddad4bf41d6d`에는 세척 대상 기능과 세 결과가 들어간다. `wash_carried_equipment`의 실제 fact는 `fact:7dc32ef5b0f00c158983cd979a932f9e6ba9449b743d0dc5b93a48e86cc51872`다. r6에서도 같은 ID와 `admission.rule_ref=washing_target`을 확인했다. `composition_rules.py`의 `FUNCTION_EFFECT_RESULTS`는 이 기능에서 해당 결과로 가는 방향을 명시한다. 이는 사실 관계로서 맞으며 삭제할 이유가 없다.
4. **문제 2 문장.** `description_composition_planner.py:12` 및 `:121` 부근은 세척 기능·결과를 `detail_reason`으로 보낸다. `_expanded()`는 이를 배제하지 않는다. `description_composition_results.py:166`의 세척 합성, `description_composition_lexicon.py:185`의 `WASH_TARGET` 조건으로 현재 문장이 만들어진다.

> 물로 피와 옷의 때를 씻어낼 수 있다. 세척한 옷은 완전히 젖는다. 이때 접근 가능한 물 공급원과 세척당 물 10단위가 필요하다. 세제는 선택 사항이며 이동하면 중단된다.

실제 expanded segment가 위 block과 세척 function/effect/condition refs를 갖는다. 참조 연결 오류가 아니라 **공개 목적 선택 오류**다. “양말을 물로 씻을 수 있다”로 바꿔도 양말의 용도 설명에 세척 대상 관리가 남는다. 세척 사실은 내부 근거로 보존하고 양말의 DVF 공개 용도에서는 제외하는 것이 타당하다.

패치도 `recovery_sources.py:2706` 이후가 양말의 `receive_garment_patch`/`remove_garment_patch`와 바늘·실·천의 `apply_garment_patch`/`unpick_garment_patch`를 구분한다. 현재 양말 문장의 “의류의 구멍에 천을 덧대거나 패딩을 추가할 수 있다”는 대상의 관리 가능성을 도구 능력처럼 읽히게 한다. 대상 사실의 보존과 문장 선택을 분리해야 한다. 착용 자체와 `worn_location=Socks`는 실제 용도·정체성으로 남기되, 소지 여부·이동 중단·중복 착용 설명은 제거한다.

추가 발견: Cotton 양말 compact에도 “데님·가죽을 찢을 때는 가위가 필요하다”가 붙는다. 선언은 이미 Cotton을 식별한다. 일반 fabric 조건을 정확한 적용 재질에 맞춰 선택하지 않은 문제이며, 모든 직물의 조건을 양말 설명에 나열해서는 안 된다.

### 비누: 세척제 용도는 유지하고 행동 전체의 결과는 분리

`Base.Soap2`에는 `wash_equipment` fact `fact:964b4077b4e9592a527187c078224979762ed0075cb17fdff7e7b1c5a541e8d4`, `wash_body` fact `fact:84c8cac63bfaf4156472776442d5357058d25c6b302c424130d58e89fdabe2d4`가 있다. 각각 세척제 rule에 근거한다. 양말의 `washing_target`과 혼동할 필요가 없다.

문제 1은 몸 세척과 혈흔 제거를 result로 연결하지만 때 제거는 별도 block으로 보존한다. `description_composition_families.py:342` 이후는 몸 세척과 두 결과를 요약하고 장비 세척은 expanded로 둔다. planner의 `DETAIL_FUNCTIONS`에는 **대상의 관리뿐 아니라 세척제의 실제 용도인 `wash_equipment`도 포함**되어 있다. 그 결과 비누 compact는 다음처럼 몸 세척을 앞세우고 의류는 결과절로만 나타난다.

> 물을 쓰는 몸 세척의 세척제다. 처리한 신체·의류 부위의 피·때를 지우며 세제 없이도 씻을 수 있고 물이 부족하면 일부만 씻긴다.

교정은 “몸과 의류·장비를 물로 씻을 때 쓰는 세척제다”처럼 두 확인된 용도를 역할로 묶는 방향이다. 물 부족 시 일부만 씻김, 젖음, 부위당 물·세제 소비, 화장 제거, 이동 중단은 행동의 처리 정보다. 비누의 기능 결과로 과장하거나 의류 전체에 같은 물 부족 결과를 확장하지 않는다. `CleaningLiquid2`도 동일 세척 family 출력을 확인했으나 다른 독립 역할까지 이번에 전부 감사한 것은 아니다.

### 양말과 라이터: 불쏘시개 재료와 점화 도구

원본 `lua/server/Camping/camping_fuel.lua:34,60`은 Clothing을 연료/불쏘시개 분류에 등록한다. `lua/client/Camping/ISUI/ISCampingMenu.lua:46–62`는 착용·직물 조건을 검사하고 `:129`는 StartFire 태그 또는 Lighter/Matches를 별도로 선택한다. `lua/client/Camping/TimedActions/ISLightFromLiterature.lua:46–52`는 `self.item` 제거, `self.lighter:Use()`, lightFire 요청을 구별한다. 바비큐/벽난로의 대응 timed action도 `ISBBQLightFromLiterature.lua:45–46`, `ISFireplaceLightFromLiterature.lua:49–50`에서 이 구분을 유지한다.

| 항목 | A의 실제 의미 | 문제 1 좌표/관계 | 현재 문장 결함 |
| --- | --- | --- | --- |
| 양말 연료 | `supply_campfire_fuel`, `supply_hearth_fuel` | `block:08c7161872441a6d7cbac492efc2b6a4f43ea95465157cbbd1872408d2e38c93`; 대상별 variant | 같은 연료 용도를 나눠 쓰며 착용·용기·이동 조건을 반복 |
| 양말 불쏘시개 | `provide_campfire_tinder`, `provide_hearth_tinder`, `provide_industrial_tinder` | `block:77c682a2097dc2ad845a2697642f728a1ae785ef222f80db33a2a7ac8d8290b8`; 대상별 variant | 발화 도구, 꺼진 대상, 소모, 드럼 상태 등 행동 전체 조건을 대상마다 출력 |
| 라이터 | `light_campfire`, `ignite_hearth_with_tinder/petrol`, `ignite_industrial_tinder/fire_with_petrol`, `request_corpse_burning`; 초 점화의 `tool` | 예: `light_campfire` fact `fact:3cc8ff94fe97a3f591cc747aa91e501fd8853853163e1b76a6eb9fbf3d6b8115`; 초 점화 role은 별도 context branch | 점화 도구 역할은 맞지만 expanded가 수단·대상별 절차를 모두 설명 |

A `recovery_sources.py:3272` 이후의 heat operation 선택과 `:3320` 부근 캠핑 함수, 문제 1의 `FUNCTION_VARIANT_GROUPS`는 역할 분리를 보존한다. 문제 2 `description_composition_results.py:184–254`는 compact에서 연료/불쏘시개를 합성하지만 expanded는 `_expanded()`의 동일 qualifier 기준으로 나뉘어 조건마다 문장화된다. 같은 용도의 다른 대상이 같은 문장으로 묶이려면 조건 문자열까지 같아야 하는 구조가 반복을 만든다.

공개 용도는 “연료”, “불쏘시개”, “점화 도구”로 각각 보존하고 메뉴에서 확인된 대상 범위를 설명하면 된다. 비프로판 바비큐, 통나무가 든 드럼 등 **대상의 의미를 한정하는 조건**은 남길 수 있다. 걷기 중단·인벤토리 이전·반복 validity·일회 사용은 생략한다. 기존 화로 클라이언트 비활성 등 A의 근거 한계를 지우고 “모든 화로에 불을 붙인다”로 확대해서는 안 된다. 라이터의 확인된 휴대 조명 역할도 점화에 흡수하지 않는다.

### 통조림: 개봉 입력 → 결과 식품 → 요리 재료

원본의 관계는 다음과 같다.

| 원래 item | 제작법 근거 | 도구 | 결과 선언과 내용물 근거 |
| --- | --- | --- | --- |
| `CannedCorn` | `scripts/recipes.txt:1916` Open Canned Corn | `keep [Recipe.GetItemTypes.CanOpener]` | `CannedCornOpen`; `scripts/items_food.txt:158–169`의 Food, EvolvedRecipe 목록, 활성 `EvolvedRecipeName=Corn` |
| `CannedSardines` | `scripts/recipes.txt:1988` | 도구 입력 없음 | `CannedSardinesOpen`; `items_food.txt:269` 이후 `EvolvedRecipeName=Sardine`와 요리 목록 |
| `CannedCornedBeef` | `scripts/recipes.txt:1906` | 도구 입력 없음 | `CannedCornedBeefOpen`; `items_food.txt:49` 이후 `EvolvedRecipeName=Corned Beef`와 요리 목록 |

`scripts/items.txt:533–543`의 `Base.TinOpener`는 `DisplayName=Can Opener`, `Tags=CanOpener`다. 이 파일의 CanOpener 태그 선언은 하나다. `lua/server/recipecode.lua:35–36`은 바로 이 태그 집합을 조회한다. 한국어 `ItemName_KO.txt:1499`의 실제 표기는 “깡통 따개”다. 사용자가 말한 “통조림 따개”와 같은 식별 대상이며, 제품 문안에서는 기존 표시명 정책에 맞춰 통일하면 된다. 다른 버전·미래 태그 집합까지 단일 도구라고 일반화하지 않는다.

**정보가 좁아지는 위치:** `recovery_sources.py:4490–4538`은 consumed item과 Result를 FullType으로 해석하고 선언·callback을 확인한다. `package_opening_results[item]`에 `result_item`, clauses, evidence를 보관하며 결과의 EvolvedRecipe와 실제 evolved recipe record를 확인한 경우에만 `prepare_opened_food_ingredient`를 만든다. 이 guard는 정확하므로 보존한다. 그러나 공개 facts에는 일반 `unpack_canned_food`, package_opening의 `material`, `prepare_opened_food_ingredient`와 포괄 조건이 남는다. `result_item`, 식품의 내용물 이름, 도구 집합이 구조화된 인자로 전달되지 않는다. `recovery_migration.py:3394` 부근도 일부 output_identity를 declared Result와 native 생성 보장 사이의 경계로 보관한다. 선언된 결과 정체성과 실제 결과 전달 성공 보장을 구분해야 하며, 전자를 이름으로 설명하는 것까지 막을 이유는 없다.

`blocks.json`의 CannedCorn은 개봉 block `block:b5efabd605512413004932f8a25678784d6d3ce702384ddbbd1abebd2c1c34ab`, package material/context block, 개봉 후 조리 block `block:df1f8945bd486af7356d0214b17676c98cc9aaea2050859a5e830e454367fc7e`로 나뉜다. 마지막 fact는 `fact:f4c22fc36801d06112401a98edaddaf713514c75a60836a9b0dc3d3548c0e10c`다. 결과 식품 이름은 이 블록들에 없다.

`description_composition_families.py:782–785`는 OPENING/CAN_OPENING을 구분하되 각각 “개봉해 내용물을…”/“맞는 개봉 도구로 내용물을…”라는 고정 일반문으로 만든다. CannedCorn compact의 두 문장은 이 개봉 frame과 별도 개봉 후 재료 기능에서 나온다. 정어리·콘비프 출력에는 “맞는 개봉 도구”가 없으므로 **도구 유무 분기는 이미 정확하다**. 부족한 것은 명시적 도구명·내용물명과 관계의 합성이다.

CannedCornOpen에는 실제 `food_preparation/ingredient` block `block:3aa66b1536e159e91dd7ce76a2d1e5f6623561fcaa03362685f02ab62d8b83cc`, 별도 `eat_food`, `supply_trap_bait`가 있다. 원래 통조림의 현재 block에는 먹기·미끼가 복사되어 있지 않다. 이 경계를 보존한다. “포만 상태가 허용하면”, “추가 재료가 없는 날음식을 받는 덫”은 열린 식품의 별도 사용 조건이며, 개봉 전 통조림 문장으로 전이시키지 않는다. 특히 미끼는 동물·덫 적합성이 있으므로 무조건적인 모든 덫의 미끼로 축약하지 않는다.

**내용물 명명 규칙:** 이름의 Open/Canned 접두사를 잘라 추측하지 않는다. 개봉 Result의 exact item을 먼저 확정하고, 그 결과의 활성 `EvolvedRecipeName` 등 명시된 식품 의미와 locale 이름을 연결한다. 옥수수는 주석 처리된 `Canned Corn`이 아니라 활성 `Corn`을 사용한다. 한국어 `EvolvedRecipeName_KO.txt:5–9`는 여전히 “옥수수 통조림/소고기 통조림/정어리 통조림”이므로, 기존 localized item label과 식품 내용물 명칭은 별개임을 처리해야 한다. 공통 식품 명칭 매핑은 가능하지만 FullType별 최종 문장 패치는 아니다. 명칭 근거가 부족한 다른 결과에는 확인된 결과 표시명을 쓰거나 해당 구절을 보류한다.

**개봉 전 직접 요리도 보존:** `TinnedBeans`의 현재 compact에는 개봉 후 재료와 직접 `food_preparation` 역할이 함께 있다. `recovery_sources.py:1841,1880`은 통조림 상태로 Bowl 및 kept CanOpener와 참여하는 Make Bowl of Beans를 별도 취급한다. `scripts/recipes.txt:207`의 Make Pot of Soup도 CannedMushroomSoup를 직접 입력으로 받는다. 따라서 “통조림은 반드시 먼저 개봉해야 조리 가능”이라는 공통 규칙은 틀리다. 직접 제작 참여와 개봉 결과의 재료 용도를 서로 다른 관계로 유지해야 한다.

## A·1·2·3별 수정과 보존

| 단계 | 직접 교정에 필요한 부분 | 이미 맞아 보존할 부분 |
| --- | --- | --- |
| A: source·사실 | 통조림의 기존 exact opening result/tool 정보를 후속 조합이 읽을 수 있는 관계로 전달. 대상 기능 키의 participant 의미를 명시적으로 전달하거나 source-rule 기반 역할 해석에 사용. 선언된 내용물과 native 성공 보장을 구별 | `washing_target`/`washing_supplies`, provide/ignite 구분, patch target/tool 구분, 결과 요리 근거 guard, 조건 적용 refs, 미확정 경계, 여러 용도. 세척 사실 삭제·r6 덮어쓰기 불필요 |
| 1: 의미 블록 | 보존된 사실에서 공개 용도 단위를 구성할 역할 해석을 지원. 개봉 입력→결과→내용물/재료의 방향 관계 수용. 보존 block과 공개 block 선택을 구분 | 정확한 role/context binding, result 방향, target variant, qualifier scope, stable ID, unresolved 관계. 세척 결과 block은 오류가 아니며 삭제하지 않음 |
| 2: 문장 조합 | `detail_reason` 이분법을 공개 용도/의미 한정/비공개 근거로 분리. expanded 전량 출력 해제. 재료·도구·대상별 주어와 목적어 선택. target variant의 공통 용도 합성, 실제 적용 재질 조건 선택, 이름 있는 통조림 관계 합성. KO/EN 동일 의미 적용 | 문장과 refs 연결, 조건이 다른 claim으로 번지지 않도록 하는 제한, 도구 유무 분기, 연료/불쏘시개 구분, family 기반 공통 교정, 다중 용도·부재/실패 구분 |
| 3: 품질 판단 | 사실 전량 공개를 수락 조건으로 삼은 부분을 바꿈. 역할이 맞는지, 용도인가 관리 절차인가, 짧은 요약인가를 실제 전후 출력에서 확인. 기존 검사 기대도 같은 의미로 조정 | 과거 읽기·실패·교정 이력, 일부 건축/제작과 독립 가구 이동 구분, Notebook 다중 용도 압축 등 유효한 교정. 이전 수락 기록은 이번 결함의 반증이 아님 |

문제 1 contract의 “모든 accepted fact를 anchor/qualifier로 보존”은 맞다. “independent block을 discard하지 말라”는 조건은 내부 자료 유지에 적용해야 하며 모든 block의 문장화를 요구해서는 안 된다. contract는 block이 문장/화면 block을 강제하지 않는다고도 명시한다.

문제 2 검사 `Iris/build/description/v2/tests/test_layer3_description_composition.py:53–74`는 expanded segment의 represented refs가 all_refs와 같아야 한다고 요구한다. 이는 **사실 보존과 문장 출력의 결합을 실제로 강제하는 지점**이다. 공개에서 빠진 근거를 무관한 문장의 refs에 붙여 이 조건만 통과시키면 안 된다. 후속에는 내부 보존된 사실과 실제 문장이 주장한 사실을 구별하도록 기존 검사 의미를 고쳐야 한다. 이번에는 검사 실행·수정 모두 하지 않았다.

문제 3 plan은 compact를 두 번째 물리적 한 줄로 정의하면서도 실제 expanded에 없는 정보를 audit/ref 보존으로 계산하지 못하게 한다. 기존 `review.json`은 673 조합/2105 items 등을 읽었다고 기록하며, closeout도 offline complete다. 이 기록을 삭제할 필요는 없지만, 현재 확인된 문장이 위키의 용도 설명인지에 대한 새 증거를 대신할 수 없다. 이번에는 상태를 변경하지 않았다.

## 공통 교정 원칙과 전후 예시

공통 순서는 **근거 보존 → 해당 item의 참여 역할 → 독립 용도와 필수 의미 한정 선택 → 이름 있는 관계 합성 → 표면별 문장**이다. 문장 수·문자 수를 먼저 자르거나 primary_use를 선택하지 않는다. 실행당 소모량·동작 순서와, 재사용 도구인지 변환·소모되는 재료인지는 다르다. 후자는 용도의 성격이므로 보존한다. “소모” 표현을 일괄 제거하지 않는다. DVF 양쪽에서 제외할 관리 절차와 compact에서는 묶어 요약하되 expanded에서 보존할 실제 독립 용도도 구분한다. 길이가 길다는 이유만으로 독립 용도를 비공개로 분류하지 않는다.

| 사례 | 현재 핵심 표현 | 제안하는 방향 |
| --- | --- | --- |
| 양말 compact | 착용, 직물 회수, 데님·가죽 가위 조건, 로프, 연료·불쏘시개 조건을 여러 문장으로 나열 | “착용하거나 천·시트 로프의 재료, 연료·불쏘시개로 쓸 수 있다.” 모든 확인된 용도는 유지하고 적용되지 않는 재질 조건과 실행 절차는 제외 |
| 양말 menu | 세척·완전 젖음·물 10단위·패치·점화 절차·착용 관리 | “양말 자리에 착용한다. 천을 회수하거나 시트 로프를 만드는 재료로 쓸 수 있다. 모닥불·비프로판 바비큐·벽난로의 연료와 불쏘시개로 쓰며, 통나무가 든 드럼의 불쏘시개로도 쓸 수 있다.” 범위 제한은 보존하며 실제 행동 절차는 출력하지 않음 |
| 비누 compact | 몸 세척 + 세제 선택 + 물 부족 결과 | “몸과 의류·장비를 물로 씻을 때 쓰는 세척제다.” 세척 대상과 구별되는 두 공급 용도를 유지 |
| 라이터 | compact의 점화/조명 개요는 있으나 menu에 대상별 실행 조건이 반복 | 점화 도구와 휴대 조명의 복합 역할 유지. 메뉴에서는 확인된 점화 대상·수단 차이만 확장하고 소모 횟수·이동 중단·재검사 절차는 제외. 미확정 화로 효과를 확정하지 않음 |
| 옥수수 통조림 | “맞는 개봉 도구로 내용물을… 개봉한 내용물을 허용하는 요리…” | “깡통 따개로 개봉해 옥수수를 요리 재료로 쓸 수 있다.” 도구·Result·Corn·요리 근거를 한 관계로 표현. 사용자의 “통조림 따개” 표기를 채택하더라도 동일 TinOpener를 가리켜야 함 |
| 정어리/콘비프 통조림 | “개봉해 내용물을… 개봉한 내용물을 허용하는 요리…” | “개봉해 정어리를 요리 재료로 쓸 수 있다.” / “개봉해 콘비프를 요리 재료로 쓸 수 있다.” 도구를 추가하지 않음. 콘비프의 최종 KO 명칭은 기존 “소고기 통조림” 표시와 공통 내용물 명칭 정책을 맞춘 뒤 결정 |
| 열린 옥수수 | 음식 준비 일반문 + 포만 조건 + 미끼 조건 | 먹기·옥수수 요리 재료·조건부 미끼를 각각 보존. 이번 조사만으로 동물/덫 후보를 전부 특정하지 않았으므로 미끼의 최종 단문은 미확정. 이것을 원래 통조림의 용도로 복사하지 않음 |

표의 짧은 문안은 물리적 fit을 측정한 결과가 아니다. 메뉴에 모든 “허용된/지정된/맞는” 조건을 다른 말로 되풀이하는 것도 해결이 아니다. 용도 범위에 필요한 대상·도구는 근거에 있는 이름을 쓰고, 사용 가능 상태를 반복하는 실행 조건은 공개 문장 자체에서 제외한다. 여러 대안 도구가 실제로 있으면 그 집합 또는 근거 있는 공통 명칭을 표현하고 단일 도구로 좁히지 않는다.

## 적용 범위와 후속 직접 교정의 최소 범위

양말만의 개별 오류가 아니다. `washing_target`은 Clothing/Weapon/Container 전체에, 세척제 frame은 Soap2/CleaningLiquid2에, 불쏘시개/연료 규칙은 같은 함수·조건 조합에, 개봉 frame은 해당 opening family에 적용된다. 따라서 후속 검토 대상은 **수정한 공통 규칙에 실제로 매칭되는 항목**이다. 현 조사에서 모든 해당 항목 수나 품질을 확정하지 않았으며 새 census나 2105개 전면 재감사를 요구하지 않는다. 별개 role은 매칭에서 분리하고, 복합 역할 조합은 보존 여부를 확인한다.

최소 변경은 다음과 같다.

1. A→1에서 이미 추출하는 개봉·가공·분해 결과와 도구 집합, 결과의 명시적 이름 및 원래 item의 용도를 설명하는 활용 관계를 조합 입력에 연결한다. 추가 조사에서 확인한 탄약 상자·농산물 자루·씨앗 봉지·전자 기기 분해까지 같은 전달 원칙을 적용한다. 개구리처럼 이미 qualifier에 정보가 전달된 경우는 표현 단계의 누락부터 고친다. 일반 raw source 재조사나 QG 재설계로 넓히지 않는다. 양말의 맞는 사실은 그대로 둔다.
2. 1→2에서 대상/도구/재료/공급 역할을 공개 용도 선택에 사용한다. 새 전역 역할 체계보다 현재 function/rule/context_role에서 확정 가능한 최소 구분으로 시작한다. 비공개 근거 유지와 공개 claim refs의 차이를 표현하고, expanded를 무조건 남은 사실 전부로 만드는 흐름을 고친다.
3. 문제 2의 공통 planner·family·lexicon·results에서 위 사례를 교정한다. 기존 검사 중 all_refs=expanded 조건과 compact→expanded 링크의 의미도 변경에 맞춘다. 새 validator·seal·receipt·manifest·proof 체계는 필요하지 않다.
4. B/C는 교정된 같은 자료를 공급받는 기존 경로를 유지한다. C `product_projection.py:86` 이후는 segment를 온전히 유지하고 관계를 기준으로 묶을 뿐 문장 의미를 고치지 않는다. 이곳에서 문장을 숨기는 해결은 피한다. B `IrisAltTooltip.lua:81–90`은 모든 행의 원문을 측정해 폭을 늘린다. 길어진 문장을 한 줄에 그리는 것과 간결한 DVF 요약은 별개이므로 producer 교정이 선행되어야 한다.

완료 판단은 교정된 실제 자료에서 양말의 관리/세척 절차가 빠지고 용도는 남는지, 비누·라이터가 각각 공급/도구와 복합 역할을 유지하는지, 통조림 이름·도구·개봉 전후 관계가 근거와 맞는지, 공통 규칙의 영향 항목에 같은 오류가 재발하지 않는지로 한다. 공개에서 빠진 사실은 내부 근거에 남고, 새 주장이 근거 없이 생기지 않아야 한다. KO/EN의 의미·조건 범위도 맞아야 한다. 후속 구현 시 필요한 기존 검증은 정확한 관련 명령 exit 0일 때만 PASS라고 하며, 이번 보고서 작성에는 테스트를 실행하지 않았다.

실제 Tooltip 완료는 Alt에서 최대 **4개 물리적 화면 줄**, 1 L2 소분류 / 2 DVF 간결한 용도 요약 / 3 획득 장소 / 4 유효한 L4 레시피·우클릭·자유 조리 후보 무작위 표시를 확인해야 한다. 폭 확장·여러 문장 공백 연결만으로 용도 요약 완료를 주장하지 않는다. B의 연결·표시는 사용자 인게임 통과 사실을 보존하되 설명 품질 수락으로 확대하지 않는다. C는 기존 `implemented_only`이며 메뉴 의미 품질은 미통과다.

구조적으로 필요한 변화는 개봉 관계 정보 전달과 내부 보존/공개 claim 분리다. 현재 owner 경계 안에서 직접 교정할 수 있는 위치를 찾았으므로 **별도 문제·계획·Gate 수립이 선행되어야 할 사유는 발견하지 못했다**. 실제 구현 중 기존 schema가 관계나 비공개 구분을 담지 못하면 해당 모델/consumer의 최소 변경을 함께 수행할 사안이며, 이를 전체 워크플로우 재시작의 근거로 삼지 않는다.

## 추가 조사: 통조림 밖의 구체적 관계 전달

같은 날짜에 수행한 보고서 개정 조사다. 새 파일·검사·생성물은 만들지 않았다. 추상 표현을 만드는 `description_composition_families.py`, `description_composition_lexicon.py`를 출발점으로 아래 사례만 선정했다. **통조림 밖에서도 발생하지만 원인은 하나가 아니다.** 상류 정보의 구조화된 전달 누락, 이미 전달된 qualifier의 표현 손실, 실제 근거 해석 한계, 동적 대상·복수 대안의 정당한 일반화를 구별해야 한다.

추가로 실제 KO compact/expanded와 blocks를 함께 읽은 항목은 `Base.223Box`, `Base.SackProduce_Carrot`, `farming.CarrotBagSeed`, `Base.Frog`, `Base.Remote`, `Base.BrokenFishingNet`, `Base.Key1`이다. `Base.Scissors`, `Base.Battery`, `Base.FishingNet`의 출력은 비교용으로 읽었다. `Base.Radio`와 `Base.DigitalWatch2`에서 이 분해 결함의 양성 사례를 확인하지 못했으므로 전자제품 전체에 같은 결함이 있다고 집계하지 않았다. 이 추가 조사는 카테고리 전수 감사, 새 census, 모든 영어 문장 확인이 아니다.

### 공통 경로에서 확인한 구분

- `lexicon.core()`(`:341` 이후)는 direct_function 이름으로 고정 문구를 조회한다. 결과 item·도구 집합을 받는 일반 인자가 없다. planner는 전달받은 fact/context/qualifier를 유지하지만 source observation의 recipe clauses를 다시 해석하지 않는다. 따라서 provenance에 정보가 있다는 사실만으로 문장 조합 입력에 관계가 전달됐다고 할 수 없다.
- `families.packaging_frames()`(`:774` 이후)는 function/activity/predicate 일치로 고정 문구를 선택한다. 탄약은 “탄약”, 자루는 “농산물”, 개구리는 “허용된 칼…고기”다. 일부 predicate를 `complete`로 취급해 expanded에서도 조건문을 생략하고 “complete condition을 포함한 wording”으로 기록한다. 개구리의 실제 도구 대안·재사용 의미를 생략하는 데에도 이 경로가 적용된다. refs 보유와 표현의 충실성은 다르다.
- “허용된 재료/지정된 물품”은 어휘 자체만으로 결함을 판정할 수 없다. 결과물 이름이 사라진 경우, 실제 복수 재료의 공통 명칭인 경우, 현재 상태에 따라 대상이 정해지는 경우가 섞여 있다. 불필요한 관리 조건은 공개하지 않되, 실제 용도 대상을 설명하는 관계는 구체화해야 한다.

### 대표 사례의 사실 → A → 블록 → 문장

#### 1. 탄약 상자 — 결과 정체성 전달 누락 확인

`scripts/recipes.txt:747`의 Open Box of .223 Ammo는 `223Box`를 입력으로, `223Bullets=8`을 결과로 선언하며 kept 도구는 없다. `scripts/items_weapons.txt:6463–6470`은 해당 결과의 표시명을 `.223 Ammo`로 선언한다. 이름 접두사를 추측할 필요가 없다.

A `recovery_sources.py:4467–4512`는 이 recipe를 `unpack_ammunition`으로 분류하고 exact result 선언과 Ammo category를 확인하여 `package_opening_results`에 `Base.223Bullets`를 기록한다. 문제 1의 `block:cebc92f09b13266febd5a1d42691c0cdd4cbd63796dd02e7d2d5e22c8d77572e`에는 `unpack_ammunition`만 있고, `block:546cad8d5d567f0a4da8917e5287f92fe2832e502eec9d03d6ee54a8307b9e28`에는 package_opening/material이 있다. 결과 탄종과 도구 없음은 구체적 관계 필드로 전달되지 않는다.

현재 compact는 “탄약이 든 상자이며 개봉해 탄약을 꺼낼 수 있다.”, expanded는 여기에 “해당 개봉법에서 요구하는 도구와 제작 조건”을 붙인다. **탄종 정체성이 사라지고 도구 없는 경로에도 포괄적인 도구 조건이 붙는 결함**이다. “개봉해 .223 탄약을 꺼낼 수 있다”는 방향은 선언된 결과에 근거한다. 8발은 recipe 선언 수량이지만 요약에 반드시 넣어야 할 정보는 아니며 native 전달 성공을 새로 보장하지 않는다. 호환 총기 목록이나 발사 성능을 상자에 복사할 근거는 이번에 확인하지 않았다.

#### 2. 당근 자루 — 통조림과 같은 결과 활용 관계 누락 확인

`scripts/recipes.txt:4071`은 `SackProduce_Carrot → Carrots=12`, `OpenSackProduce` callback을 선언한다. `scripts/items_food.txt:1129` 이후의 `Carrots`는 Food이며 Soup/Stew/Pie 등 EvolvedRecipe가 있다. A는 exact Result와 결과의 요리 참여를 확인하고 `package_opening_results` 및 `produce_sack_sources`에 opened item을 저장한다(`recovery_sources.py:4515` 이후).

문제 1에는 `unpack_produce` block `block:9f123554e453cb323118f21bf9bdc6132225c1f417fdff0b5bb8630aa31a8af9`, `prepare_opened_food_ingredient` block `block:f81b435063bacba3073e9057f269d44ef512b63871630e16868bc2c79b5ad78c`가 있지만 Carrots 정체성이 없다. 현재 compact는 “농산물을 꺼내는 자루이며 개봉해도 신선도가 회복되지는 않는다. 개봉한 내용물을 허용하는 요리의 재료로 쓸 수 있다.”다.

“자루를 열어 꺼낸 당근을 요리 재료로 쓸 수 있다”로 관계를 설명할 근거가 있다. freshness 복사 경계는 내부에 유지하되 자루의 주용도를 대신하는 첫 설명으로 둘 필요가 없다. A에 있는 역포장 recipe를 추정하지 말라는 제한도 유지한다. 당근의 모든 먹기·미끼·기타 활용을 자루에 복사하는 교정은 아니다.

#### 3. 씨앗 봉지 — 결과와 파종의 연결은 있으나 작물 정체성 누락 확인

`scripts/farming.txt:740–747`은 `farming.CarrotBagSeed → farming.CarrotSeed=50`을 선언한다. `lua/server/Farming/farming_vegetableconf.lua:514,524`는 Carrots의 `seedsRequired=12`, `seedName=farming.CarrotSeed`를 연결한다. A `recovery_sources.py:2590–2599`는 `seed_sources`에 crop과 count를 저장하고, `:4535` 이후는 개봉 결과가 seed_forms에 있을 때만 `sow_extracted_seeds`를 추가한다.

문제 1의 해당 item에는 `unpack_seeds`, package_opening/material, `sow_extracted_seeds`, “12 loose seeds per furrow” 조건이 전달된다. 그러나 crop=Carrots와 result_item 관계는 명시적 의미 인자로 없다. 문제 2 `families.py:354–369`는 수량을 읽어 “봉지를 개봉해 꺼낸 **이 작물**의 낱알 씨앗 12개…”라고 한다. 즉 **개봉 봉지와 낱알 소비의 구분은 이미 정확하지만 작물 이름 대신 지시어만 남는 전달 결함**이다.

“봉지를 열어 꺼낸 당근 씨앗을 파종하는 데 쓸 수 있다”는 방향으로 활용을 표현할 수 있다. 50개는 포장 결과 수량, 12개는 고랑당 소비량으로 서로 다른 관계다. 숫자를 옮겨 적거나 봉지 자체를 파종에 소모한다고 표현하면 안 된다. 성장·수확 성공은 이 관계로부터 도출되지 않는다. 씨앗의 결과 활용을 봉지 용도로 연결하는 A의 guard는 다른 결과 활용 관계에도 참고할 수 있다.

#### 4. 개구리 손질 — 입력 전달 후 표현 단계의 일반화 확인

`scripts/recipes.txt:1130`의 Slice Frog는 `keep [Recipe.GetItemTypes.SharpKnife]/MeatCleaver`, `Frog`, `Result:FrogMeat`를 선언한다. `recipecode.lua:57–58`은 SharpKnife 태그를 조회한다. `scripts/items_weapons.txt`의 태그 선언에서 Machete(`:395`), Hunting Knife(`:3417`), Stone Knife(`:3467`), Kitchen Knife(`:3943`)를 확인했다. 이들과 별도의 MeatCleaver 대안을 단일 “식칼 하나”로 좁히면 틀리다.

A `recovery_sources.py:3933–3969`는 exact clauses를 확인하고 material/tool 참여를 분리한다. `FROG_PREPARATION` predicate에는 SharpKnife-group **또는** MeatCleaver, keep, FrogMeat가 들어 있다. 문제 1의 material/context block `block:14899531c3411220e675aead4a25d4f691efb84c9f1feb4eb980699afc05e39e`와 function block `block:f93659b6e5b436e9e2ec8d9dc1a3b3d0e299a2e45365e517627ea33d36795bb6`에 붙은 qualifier에서 이 문자열을 실제로 확인했다.

현재 compact/expanded는 모두 “허용된 칼로 손질해 고기를 꺼내는 개구리 재료다.”다. **상세 정보가 완전히 전달되지 않은 통조림과 달리, 여기서는 도구 대안·결과·재사용 정보가 qualifier에 있으나 packaging frame이 일반화한다.** 구조화된 인자를 추가하면 공통 처리가 쉬워지지만, 기존 정보가 없는 것처럼 재조사할 사안은 아니다.

교정 방향은 compact에서 “칼로 손질해 개구리 고기를 얻는 재료다”처럼 실제 변환 용도를 요약하고, expanded에서 확인된 칼 집합 또는 정확한 공통 명칭과 식칼 대안, 도구가 보존된다는 차이를 설명하는 것이다. 최종 locale 명칭은 선언/번역에서 연결한다. 이번에는 FrogMeat의 모든 후속 요리·섭취 관계를 추적하지 않았으므로 원래 Frog에 “요리 재료로 쓴다”까지 전이하는 문안은 확정하지 않는다.

#### 5. 리모컨 분해 — 결과 정체성 누락과 정당한 확률 한정이 함께 존재

`scripts/recipes.txt:2024–2034`의 Dismantle TV Remote는 Remote, kept Screwdriver group, **Result:Receiver**를 선언한다. `recipecode.lua:840`의 DismantleTVRemote callback은 ElectronicsScrap을 추가하고 확률 조건 아래 Battery를 생성·추가한다. `Recipe.GetItemTypes.Screwdriver`는 `recipecode.lua:47–48`에서 태그를 조회하며 저장소 item 태그 검색에서는 `items_weapons.txt:4178`의 Screwdriver 선언을 확인했다.

A `recovery_sources.py:4372–4412`는 이 recipe/callback/도구 group과 exact output 선언을 읽는다. 그러나 output participant는 건너뛰고 입력에 `dismantle_electronics` 및 transformation_target을 부여한다. 결과가 scrap이거나 해당 callback인 경우에는 `SCRAP_RECOVERY`를 추가한다. 이로써 **Receiver는 observation의 Result로만 남고, 공개 의미 입력은 generic 분해와 scrap 조건으로 축소된다.** 문제 1의 function block은 `block:654dddd6022615bf8d6dc27fb3c579701e3d22aad89500c24054f0432d7390f8`, transformation context block은 `block:05e261f724c0802c956bd7cc013e9578a86da073905a59258fbf5dab3d19e0ba`다. 별도 electronic_assembly/material block도 남아 있다.

현재 compact는 제작 재료 용도 다음에 “전자 기기 분해에 쓰는 가공 대상이다. 분해해 전자 부품을 회수할 수 있다.”, expanded는 전자 스크랩과 “추가 부품은 보장되지 않는다”를 설명한다. 결과 Receiver를 명시하지 않는 것은 확인된 누락이다. 다만 **건전지를 항상 회수한다고 바꾸면 오류**다. 결과 관계를 declared result / unconditional callback addition / conditional callback addition으로 구별해야 한다. “드라이버로 분해해 수신기와 전자 스크랩을 얻는 재료이며, 건전지도 나올 수 있다”는 방향은 각 관계의 근거와 가능성을 분리하는 예시다. 정확한 KO 표시명과 실제 native 결과 전달 보장은 별개다.

리모컨은 해체 대상이지만 회수 재료를 공급하는 실제 용도가 있다. 양말의 관리 세척과 달리 transformation_target이라는 이유만으로 공개에서 제외하면 안 된다. 또한 타이머·원격 조작 부품 제작의 독립 material 역할을 분해 용도에 흡수하지 않는다. Receiver나 Battery의 모든 용도를 원래 리모컨에 전이하지 않는다.

#### 6. 부서진 어망 — 근거 해석 한계로 남겨야 하는 반례

`scripts/recipes.txt:1428`의 Get Wire Back은 `Result:Wire;3`라는 원문을 갖는다. A `recovery_sources.py:3953–3956`은 이 semicolon 결과를 opaque로 명시하고 예외적으로 입력 참여만 수용한다. 문제 1의 wire_recovery/material 및 `process_broken_fish_net` 블록과 qualifier도 “native parser 없이 Wire identity/count를 확정하지 않음”을 보존한다.

현재 “철사 회수 제조법에 쓰는 부서진 어망이다”는 이 bounded 사실을 설명한다. 이름이 구체적이지 않아서 생긴 통조림형 전달 누락으로 분류하지 않는다. **철사 3개를 확정 획득**한다고 교정해서는 안 된다. 결과 해석의 범위를 바꾸는 조사는 이번에 하지 않았으며, 원문의 세미콜론을 등호로 고쳐 읽지 않았다.

#### 7. 열쇠 — 동적 일치 관계의 정당한 일반화와 소모 역할 구분

`lua/client/TimedActions/ISLockDoor.lua:11`은 key ID 일치를 검사한다. `ISPadlockAction.lua:35–38`은 맞는 key를 찾아 제거한다. A `DOOR_KEY_USE`/`PADLOCK_KEY_USE`(`recovery_sources.py:1624,1626`)는 문 잠금에는 열쇠가 소모되지 않지만 자물쇠 제거에는 해당 열쇠를 소모함을 구별한다. 문제 1의 `Base.Key1`에는 `operate_door_lock`와 `remove_matching_padlock`가 별도 block으로, 이 qualifier와 함께 전달된다.

현재 “맞는 닫힌 문의 잠금을 조작하며 소모되지 않는다”와 “맞는 구조물 자물쇠를 제거할 때 소모하는 열쇠다”는 이 차이를 유지한다. “맞는”은 숨겨진 고정 FullType 이름이 아니라 플레이 상태의 key ID 관계다. 특정 차종이나 문 이름으로 바꾸지 않는다. 이 사례는 실행당 숫자를 생략하더라도 **재사용/소모의 용도 차이는 반드시 남겨야 한다**는 반례다. 전체 compact가 긴 문제와 해당 한정 표현의 의미 타당성은 별개다.

### 확인 후보와 미확인 후보

양말·가위의 “직물 회수”는 추가 구체화 후보다. `recipecode.lua:1110` 이후는 exact clothing definition 또는 FabricType→material을 선택하고, 오염 상태에 따른 Dirty 결과 및 기술·확률에 따른 수량/실 추가를 별도로 처리한다. A `recovery_sources.py:2753` 이후가 fabric context에 `FABRIC_ACTION`을 부여하고 현재 문장이 이를 일반 조건으로 출력하는 것은 확인했다. 그러나 이번에는 `ClothingRecipesDefinitions`의 모든 재질·아이템 override와 A에서 해석한 relation을 끝까지 대조하지 않았다. **Cotton 양말에 Denim/Leather 조건이 붙는 기존 결함은 확정, 정확한 회수 결과 집합의 전달 누락은 추가 확인 후보**로 구분한다. “회수 재료·양은 달라진다”를 전부 거짓이라고 하거나 하나의 무조건적 결과로 바꾸지 않는다.

차량 부품의 “지정 도구”, 가구 이동의 “해당 도구”, 낚시의 “맞는 미끼”, 수납의 “허용된 물품”도 표현 검색에서 발견했다. 이들이 source-specific 관계 전달 누락인지 실제 동적/복수 대상인지 이번에는 각 원본까지 추적하지 않았다. 따라서 결함 확정 목록에 넣거나 각 카테고리 전면 교정을 요구하지 않는다. Battery의 여러 전원 대상이 이미 family에서 합성되는 출력도 확인했으나 모든 대상의 입력 근거를 이번에 재감사하지 않았다.

### 공통 교정의 범위와 의미별 경계

추가 조사로 후속 직접 교정 범위는 **통조림 전용 이름 보완에서, 확인된 입력·도구·변환 결과·제한된 결과 활용 관계를 전달하는 공통 경로 보완으로 넓어진다.** 기존 A/1/2 owner 안에서 다룰 수 있다는 판단은 유지한다. 별도 계획·Gate·검증 체계가 필요한 새 구조 경계는 발견하지 못했다.

| 공통으로 전달·표현할 정보 | 의미별로 반드시 구분할 것 |
| --- | --- |
| source input과 role, exact result item, named tool/material set, 근거 refs | tool keep / 소모·변환 input / 결과 output을 서로 바꾸지 않음 |
| 실제 관계에 연결된 locale 명칭 | FullType 문자열의 접두사 제거, 이름만으로 결과나 용도 추정 금지 |
| 도구·재료의 대안 집합과 결합 관계 | SharpKnife **또는** MeatCleaver, 도구 **및** 재료를 같은 연결어로 처리하지 않음. 대안 집합을 단일 도구로 축소하지 않음 |
| 선언된 변환 결과와 callback 결과 | declared result, 무조건 추가 요청, 확률/상태 조건 결과, 해석 미확정 결과를 구별 |
| 원래 item의 활용을 설명하는 제한된 결과 관계 | 자루→당근→요리, 봉지→낱알→파종은 근거 guard로 연결. 결과의 임의 용도까지 재귀적으로 복사하지 않음 |
| 공개 설명과 내부 근거의 구분 | 관리 절차만 비공개로 둘 수 있으며 실제 독립 용도는 길이 때문에 비공개로 돌리지 않음 |

구조화된 관계가 이미 있는 경우 이를 보존하고, 자연어 qualifier에만 확정 정보가 있는 경우 해당 source rule의 의미를 인자로 전달하는 최소 보완을 검토한다. 문장 조합기가 임의로 raw recipe나 기존 prose를 재해석하는 별도 사실 생산자가 되어서는 안 된다. 모든 raw 조건을 구조화하는 대규모 사업으로 넓힐 필요도 없다.

compact는 확인된 용도의 공통 명칭과 핵심 관계를 짧게 요약하고, expanded는 실제 독립 용도·대안·대상 범위를 이해할 만큼 보존한다. 예를 들어 리모컨의 제작 재료/분해 회수, 라이터의 점화/조명은 실제 복합 역할이다. 세척 대상 관리와 같은 이유로 제외할 수 없다. “소모” 또한 연료·불쏘시개·변환 재료의 성격 또는 도구 재사용 여부를 설명하는 경우 유지하고, 실행당 횟수·작업 순서와 구분한다.

후속 확인은 보고서의 예시 몇 개가 맞는지에 그치지 않는다. **수정한 공통 규칙의 실제 적용 항목과 그 항목의 복합 역할 조합**, 도구 없음/단일/복수 대안, 확정/조건부/미확정 결과, 직접 사용/결과를 거친 활용을 함께 확인해야 한다. 영향 없는 저장소 전체의 재검증, 새로운 전면 품질 감사, 별도 census/proof artifact로 확대하지 않는다. 이번 조사에서는 이 확인을 실행한 것으로 주장하지 않는다.
